package PGP_Encrypt_Decrypt_Armor_Error;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator;
import org.bouncycastle.openpgp.operator.jcajce.JcePGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyDataDecryptorFactoryBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyKeyEncryptionMethodGenerator;

import java.io.*;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;

public class Main3 {

    //private static String publicKeyPath = System.getProperty("user.dir")+"/keys/Public_Key.asc";
    private static String stsPublicKeyPath = "pub_rsa_kleo.asc";
    //private static String privateKeyPath = System.getProperty("user.dir")+"/keys/Private_Key.asc";
    private static String stsPrivateKeyPath = "secret_rsa_kleo.asc";
    private static String passwordString = "mypassphrase";

    public static void main(String[] args) throws NoSuchProviderException, IOException, PGPException {
        System.out.println("https://stackoverflow.com/questions/62305625/i-have-been-working-on-pgp-encrypt-and-decrypt-for-byte-with-bouncy-castle-api");
        Security.addProvider(new BouncyCastleProvider());
        System.out.println("\nTest with Java version: " + Runtime.version() + " BouncyCastle Version: " + Security.getProvider("BC") + "\n");

        byte[] plaintext = "This is my plaintext".getBytes("UTF-8");
        byte[] ciphertext = encrypt(plaintext);
        byte[] decryptedtext = decrypt(ciphertext);

        System.out.println("plaintext: " + bytesToHex(plaintext));
        System.out.println("decrytext: " + bytesToHex(decryptedtext));
        System.out.println("plaintext equals decryptedtext: " + Arrays.equals(plaintext, decryptedtext));

        System.out.println("\nciphetext: " + bytesToHex(ciphertext));
        System.out.println("ciphertext String: " + new String(ciphertext, "UTF-8"));

// bcprov-jdk15to18-165.jar
// bcpg-jdk15on-165.jar
// OpenJDK 11.0.5
    }

    public static byte[] decrypt(byte[] encrypted)
            throws IOException, PGPException, NoSuchProviderException {
        Security.addProvider(new BouncyCastleProvider());
        InputStream keyIn = new BufferedInputStream(new FileInputStream(stsPrivateKeyPath));
        char[] password = passwordString.toCharArray();
        //char[] password = "".toCharArray();
        InputStream in = new ByteArrayInputStream(encrypted);
        in = PGPUtil.getDecoderStream(in);
        JcaPGPObjectFactory pgpF = new JcaPGPObjectFactory(in);
        PGPEncryptedDataList enc;
        Object o = pgpF.nextObject();
        if (o instanceof PGPEncryptedDataList) {
            enc = (PGPEncryptedDataList) o;
        } else {
            enc = (PGPEncryptedDataList) pgpF.nextObject();
        }
        Iterator it = enc.getEncryptedDataObjects();
        PGPPrivateKey sKey = null;
        PGPPublicKeyEncryptedData pbe = null;
        PGPSecretKeyRingCollection  pgpSec = new PGPSecretKeyRingCollection(
                PGPUtil.getDecoderStream(keyIn), new JcaKeyFingerprintCalculator());
        while (sKey == null && it.hasNext()) {
            pbe = (PGPPublicKeyEncryptedData) it.next();
            sKey = PGPExampleUtil.findSecretKey(pgpSec, pbe.getKeyID(), password);
        }
        if (sKey == null) {
            throw new IllegalArgumentException(
                    "secret key for message not found.");
        }
        InputStream clear = pbe.getDataStream(new JcePublicKeyDataDecryptorFactoryBuilder().setProvider("BC").build(sKey));
        JcaPGPObjectFactory    plainFact = new JcaPGPObjectFactory(clear);
        PGPCompressedData   cData = (PGPCompressedData)plainFact.nextObject();
        JcaPGPObjectFactory pgpFact = new JcaPGPObjectFactory(cData.getDataStream());
        PGPLiteralData ld = (PGPLiteralData) pgpFact.nextObject();
        InputStream unc = ld.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int ch;
        while ((ch = unc.read()) >= 0) {
            out.write(ch);
        }
        byte[] returnBytes = out.toByteArray();
        out.close();
        return returnBytes;
    }

    public static byte[] encrypt(byte[] clearData)
            throws IOException, PGPException {
        Security.addProvider(new BouncyCastleProvider());
        String fileName=null;
        boolean withIntegrityCheck = true;
        boolean armor = false; // org
        if (fileName == null) {
            fileName = PGPLiteralData.CONSOLE;
        }
        PGPPublicKey encKey = PGPExampleUtil.readPublicKey(stsPublicKeyPath);
        ByteArrayOutputStream encOut = new ByteArrayOutputStream();
        OutputStream out = encOut;
        if (armor) {
            out = new ArmoredOutputStream(out);
        }
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(
                PGPCompressedData.ZIP);
        OutputStream cos = comData.open(bOut); // open it with the final
        // destination
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();
        OutputStream pOut = lData.open(cos, // the compressed output stream
                PGPLiteralData.BINARY, fileName, // "filename" to store
                clearData.length, // length of clear data
                new Date() // current time
        );
        pOut.write(clearData);
        lData.close();
        comData.close();
        PGPEncryptedDataGenerator   cPk = new PGPEncryptedDataGenerator(new JcePGPDataEncryptorBuilder(PGPEncryptedData.CAST5).setWithIntegrityPacket(withIntegrityCheck).setSecureRandom(new SecureRandom()).setProvider("BC"));
        cPk.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(encKey).setProvider("BC"));
        byte[] bytes = bOut.toByteArray();
        OutputStream cOut = cPk.open(out, bytes.length);
        cOut.write(bytes); // obtain the actual bytes from the compressed stream
        cOut.close();
        out.close();
        return encOut.toByteArray();
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuffer result = new StringBuffer();
        for (byte b : bytes) result.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
        return result.toString();
    }
}
